Configuration BasicWebServer
{
   

    Import-DscReSource �ModuleName 'PSDesiredStateConfiguration'

    Node "ECPSVR"
    {
        WindowsFeature WebServerRole
        {
            # Installs the following features
            <#
                Web-Server
                Web-WebServer
                Web-Common-Http
                Web-Default-Doc
                Web-Dir-Browsing
                Web-Http-Errors
                Web-Static-Content
                Web-Health
                Web-Http-Logging
                Web-Performance
                Web-Stat-Compression
                Web-Security
                Web-Filtering
            #>
            Name = "Web-Server"
            Ensure = "Present"
            #Source = $#Source
            }
        WindowsFeature WebAppDev
        {
            Name = "Web-App-Dev"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }
        WindowsFeature WebAspNet
        {
            Name = "Web-Asp-Net"
            Ensure = "Present"
            ##Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }

        WindowsFeature WebAspNet46
        {
            Name = "Web-Asp-Net45"
            Ensure = "Present"
            ##Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
        }

        WindowsFeature WebSocketProtocol
        {
            Name = "Web-WebSockets"
            Ensure = "Present"
            ##Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
        }

       

            

        WindowsFeature WebNetExt
        {
            Name = "Web-Net-Ext"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }
        WindowsFeature WebISAPIExt
        {
            Name = "Web-ISAPI-Ext"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }
        WindowsFeature WebISAPIFilter
        {
            Name = "Web-ISAPI-Filter"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }
        WindowsFeature WebLogLibraries
        {
            Name = "Web-Log-Libraries"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }
        WindowsFeature WebRequestMonitor
        {
            Name = "Web-Request-Monitor"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }
        WindowsFeature WebMgmtTools
        {
            Name = "Web-Mgmt-Tools"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }
        WindowsFeature WebMgmtConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }
        

            


            WindowsFeature HTTPActivation
            {
            Name = "NET-WCF-HTTP-Activation45"
            Ensure = "Present"
            #Source = $#Source
            DependsOn = "[WindowsFeature]WebServerRole"
            }

        

        # The second resource block ensures that the website content copied to the website root folder.
        File WebsiteContent {
            Ensure = 'Present'
            SourcePath = 'https://github.com/duzland/web/blob/master/index.htm'
            DestinationPath = 'c:\inetpub\wwwroot'
        }
    

            

        }
}
